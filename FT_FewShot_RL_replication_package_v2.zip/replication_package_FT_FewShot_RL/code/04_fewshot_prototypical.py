"""
Few-shot prototypical classification scaffold.

This implementation uses TF-IDF vectors as lightweight embeddings.
For a stronger replication, replace the embedding function with BERT embeddings.
"""

from pathlib import Path
import time
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support, accuracy_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed_requirements.csv"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

df = pd.read_csv(DATA)
train_df, test_df = train_test_split(
    df, test_size=0.2, random_state=42, stratify=df["label"]
)

shots = 5
support = train_df.groupby("label", group_keys=False).apply(
    lambda x: x.sample(min(len(x), shots), random_state=42)
)

vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
X_support = vectorizer.fit_transform(support["text"]).toarray()
X_test = vectorizer.transform(test_df["text"]).toarray()

labels = sorted(support["label"].unique())
prototypes = {}
for label in labels:
    idx = np.where(support["label"].values == label)[0]
    prototypes[label] = X_support[idx].mean(axis=0)

def predict_one(x):
    distances = {label: np.linalg.norm(x - proto) for label, proto in prototypes.items()}
    return min(distances, key=distances.get)

t0 = time.time()
pred = [predict_one(x) for x in X_test]
elapsed = time.time() - t0

p, r, f1, _ = precision_recall_fscore_support(test_df["label"], pred, average="weighted", zero_division=0)
acc = accuracy_score(test_df["label"], pred)

out = pd.DataFrame([{
    "model": "Few-Shot Prototypical",
    "shots": shots,
    "precision_weighted": p,
    "recall_weighted": r,
    "f1_weighted": f1,
    "accuracy": acc,
    "inference_time_ms_per_sample": elapsed * 1000 / len(test_df)
}])
out.to_csv(RESULTS / "fewshot_prototypical_metrics.csv", index=False)
print(out.to_string(index=False))
