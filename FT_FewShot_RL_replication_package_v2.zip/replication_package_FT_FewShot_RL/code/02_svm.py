from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed_requirements.csv"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

def load_data():
    if not DATA.exists():
        raise FileNotFoundError("Run 00_preprocess_dataset.py first.")
    return pd.read_csv(DATA)

def save_metrics(name, y_true, y_pred, elapsed_train=None, elapsed_infer=None):
    p, r, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="weighted", zero_division=0
    )
    acc = accuracy_score(y_true, y_pred)
    out = pd.DataFrame([{
        "model": name,
        "precision_weighted": p,
        "recall_weighted": r,
        "f1_weighted": f1,
        "accuracy": acc,
        "training_time_seconds": elapsed_train,
        "inference_time_ms_per_sample": elapsed_infer
    }])
    out.to_csv(RESULTS / f"{name.lower().replace(' ', '_')}_metrics.csv", index=False)
    print(out.to_string(index=False))

import time
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC

df = load_data()
X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["label"], test_size=0.2, random_state=42, stratify=df["label"]
)

model = Pipeline([
    ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1)),
    ("clf", SVC(kernel="linear", C=1.0))
])

t0 = time.time()
model.fit(X_train, y_train)
train_time = time.time() - t0

t1 = time.time()
pred = model.predict(X_test)
infer_ms = (time.time() - t1) * 1000 / len(X_test)

save_metrics("SVM", y_test, pred, train_time, infer_ms)
