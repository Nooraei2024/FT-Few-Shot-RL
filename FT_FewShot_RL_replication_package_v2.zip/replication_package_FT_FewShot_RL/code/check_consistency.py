"""Small consistency checks for the extracted manuscript results."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
WORKBOOK = ROOT / "results" / "extracted_results_from_manuscript.xlsx"

EXPECTED = {
    ("FR/NFR Classification", "Supervised (SVM)", "F1-Score"): 0.93,
    ("FR/NFR Classification", "FT Few-Shot RL", "F1-Score"): 0.86,
    ("NFR Binary Classification", "FT Few-Shot RL", "F1-Score"): 0.89,
    ("NFR Multi-Class", "FT Few-Shot RL", "F1-Score"): 0.83,
    ("NFR Multi-Class", "Supervised (SVM)", "Accuracy"): 0.87,
}


def nearly_equal(a: float, b: float, eps: float = 1e-9) -> bool:
    return abs(float(a) - float(b)) <= eps


def main() -> None:
    perf = pd.read_excel(WORKBOOK, sheet_name="Table3_Performance").dropna(how="all")
    failed = []
    for (task, model, metric), value in EXPECTED.items():
        row = perf[(perf["Task"] == task) & (perf["Model"] == model)]
        if row.empty:
            failed.append(f"Missing row: {task} / {model}")
            continue
        observed = row.iloc[0][metric]
        if not nearly_equal(observed, value):
            failed.append(f"{task} / {model} / {metric}: expected {value}, observed {observed}")

    if failed:
        print("Consistency check failed:")
        for item in failed:
            print(" -", item)
        raise SystemExit(1)

    print("Consistency check passed. Key reported values are present in the workbook.")


if __name__ == "__main__":
    main()
