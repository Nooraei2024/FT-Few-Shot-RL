"""
BERT fine-tuning scaffold for requirements classification.

This script assumes:
    data/processed_requirements.csv with columns text,label

It saves predictions and metrics into results/.
"""

from pathlib import Path
import time
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

import torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed_requirements.csv"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

class ReqDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=128):
        self.enc = tokenizer(list(texts), truncation=True, padding=True, max_length=max_length)
        self.labels = list(labels)

    def __getitem__(self, idx):
        item = {k: torch.tensor(v[idx]) for k, v in self.enc.items()}
        item["labels"] = torch.tensor(self.labels[idx])
        return item

    def __len__(self):
        return len(self.labels)

df = pd.read_csv(DATA)
le = LabelEncoder()
df["label_id"] = le.fit_transform(df["label"])

train_df, test_df = train_test_split(
    df, test_size=0.2, random_state=42, stratify=df["label_id"]
)

model_name = "bert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(
    model_name, num_labels=len(le.classes_)
)

train_ds = ReqDataset(train_df["text"], train_df["label_id"], tokenizer)
test_ds = ReqDataset(test_df["text"], test_df["label_id"], tokenizer)

def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=1)
    p, r, f1, _ = precision_recall_fscore_support(labels, preds, average="weighted", zero_division=0)
    acc = accuracy_score(labels, preds)
    return {"precision": p, "recall": r, "f1": f1, "accuracy": acc}

args = TrainingArguments(
    output_dir=str(ROOT / "models" / "bert_requirements"),
    learning_rate=2e-5,
    per_device_train_batch_size=32,
    per_device_eval_batch_size=32,
    num_train_epochs=3,
    evaluation_strategy="epoch",
    save_strategy="no",
    logging_steps=20,
    seed=42,
)

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=train_ds,
    eval_dataset=test_ds,
    tokenizer=tokenizer,
    compute_metrics=compute_metrics,
)

t0 = time.time()
trainer.train()
train_time = time.time() - t0

metrics = trainer.evaluate()
metrics["training_time_seconds"] = train_time
pd.DataFrame([metrics]).to_csv(RESULTS / "bert_finetuning_metrics.csv", index=False)
print(metrics)
