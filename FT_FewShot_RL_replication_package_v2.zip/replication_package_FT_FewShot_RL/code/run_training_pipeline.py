"""Training/evaluation scaffold for the PROMISE requirements dataset."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC

ROOT = Path(__file__).resolve().parents[1]


def find_column(df: pd.DataFrame, candidates: Sequence[str]) -> str:
    lower = {c.lower().strip(): c for c in df.columns}
    for name in candidates:
        if name.lower() in lower:
            return lower[name.lower()]
    raise ValueError(f"Could not find any of these columns: {candidates}. Available columns: {list(df.columns)}")


def load_promise(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    text_col = find_column(df, ["Requirement", "requirements", "sentence", "text", "description"])
    label_col = find_column(df, ["Type", "class", "label", "category"])
    out = df[[text_col, label_col]].rename(columns={text_col: "text", label_col: "label"}).dropna()
    out["text"] = out["text"].astype(str).str.strip()
    out["label"] = out["label"].astype(str).str.strip()
    return out[out["text"].str.len() > 0].reset_index(drop=True)


def make_task(df: pd.DataFrame, task: str) -> pd.DataFrame:
    data = df.copy()
    label = data["label"].str.lower()
    if task == "fr_nfr":
        data["target"] = np.where(label.isin(["f", "fr", "functional", "functional requirement"]), "FR", "NFR")
    elif task == "nfr_binary":
        nfr = data[~label.isin(["f", "fr", "functional", "functional requirement"])]
        data = nfr.copy()
        data["target"] = np.where(data["label"].str.lower().str.contains("security|usability"), "Selected_NFR", "Other_NFR")
    elif task == "nfr_multiclass":
        data = data[~label.isin(["f", "fr", "functional", "functional requirement"])].copy()
        data["target"] = data["label"]
    else:
        raise ValueError("task must be one of: fr_nfr, nfr_binary, nfr_multiclass")
    return data.reset_index(drop=True)


def build_model(model_name: str) -> Pipeline:
    if model_name == "logistic":
        clf = LogisticRegression(max_iter=500, class_weight="balanced", C=1.0)
    elif model_name == "svm":
        clf = SVC(kernel="linear", C=1.0, class_weight="balanced")
    else:
        raise ValueError("This lightweight runner supports --model logistic or svm. Use method/ for the hybrid implementation.")
    return Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_features=5000)),
        ("clf", clf),
    ])


def score(y_true, y_pred) -> dict[str, float]:
    return {
        "precision": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "recall": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "f1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "accuracy": accuracy_score(y_true, y_pred),
    }


def evaluate_cross_validation(data: pd.DataFrame, model_name: str, folds: int, seed: int) -> dict[str, float]:
    model = build_model(model_name)
    x = data["text"].to_numpy()
    y = data["target"].to_numpy()
    cv = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    rows = []
    for train_idx, test_idx in cv.split(x, y):
        model.fit(x[train_idx], y[train_idx])
        pred = model.predict(x[test_idx])
        rows.append(score(y[test_idx], pred))
    return pd.DataFrame(rows).mean().to_dict()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=ROOT / "data" / "promise_nfr.csv")
    parser.add_argument("--model", choices=["logistic", "svm"], default="svm")
    parser.add_argument("--task", choices=["fr_nfr", "nfr_binary", "nfr_multiclass"], default="fr_nfr")
    parser.add_argument("--folds", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    df = load_promise(args.data)
    task_data = make_task(df, args.task)
    metrics = evaluate_cross_validation(task_data, args.model, args.folds, args.seed)
    print(json.dumps({"model": args.model, "task": args.task, **metrics}, indent=2))


if __name__ == "__main__":
    main()
