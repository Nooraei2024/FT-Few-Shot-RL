"""
Implementation notes for the FT Few-Shot RL workflow used in the paper.

The module is deliberately written as a compact research implementation rather
than a framework. It covers four pieces of the method:

1. sentence encoding through a pre-trained language model,
2. prototype-based few-shot classification,
3. a policy-gradient style decision layer,
4. confidence-weighted expert corrections in the reward/loss signal.

The reported manuscript tables are reproduced from the Excel workbook. This file
is provided to document the executable logic of the proposed method when the
PROMISE dataset and optional deep-learning dependencies are available locally.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except Exception:  # pragma: no cover - useful when only reported results are checked
    torch = None
    nn = None
    F = None


@dataclass
class ExpertCorrection:
    """One expert correction for an instance."""

    index: int
    corrected_label: int
    confidence: float


@dataclass
class RewardConfig:
    correct_reward: float = 1.0
    incorrect_penalty: float = -1.0
    uncertain_penalty: float = -0.25
    confidence_threshold: float = 0.55
    lambda_rl: float = 0.30
    mu_expert: float = 0.40
    gamma: float = 0.95


class PrototypeClassifier:
    """Nearest-prototype classifier used for the few-shot component."""

    def __init__(self) -> None:
        self.labels_: np.ndarray | None = None
        self.prototypes_: np.ndarray | None = None

    def fit(self, embeddings: np.ndarray, labels: Sequence[int]) -> "PrototypeClassifier":
        labels = np.asarray(labels)
        unique = np.unique(labels)
        prototypes = []
        for label in unique:
            members = embeddings[labels == label]
            if len(members) == 0:
                continue
            prototypes.append(members.mean(axis=0))
        self.labels_ = unique
        self.prototypes_ = np.vstack(prototypes)
        return self

    def predict_proba(self, embeddings: np.ndarray) -> np.ndarray:
        if self.labels_ is None or self.prototypes_ is None:
            raise RuntimeError("PrototypeClassifier must be fitted first.")
        distances = ((embeddings[:, None, :] - self.prototypes_[None, :, :]) ** 2).sum(axis=2)
        logits = -distances
        logits -= logits.max(axis=1, keepdims=True)
        exp = np.exp(logits)
        return exp / exp.sum(axis=1, keepdims=True)

    def predict(self, embeddings: np.ndarray) -> np.ndarray:
        probs = self.predict_proba(embeddings)
        return self.labels_[probs.argmax(axis=1)]


if torch is not None:

    class PolicyNetwork(nn.Module):
        """A small policy head over requirement embeddings."""

        def __init__(self, input_dim: int, n_classes: int, hidden_dim: int = 128) -> None:
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.10),
                nn.Linear(hidden_dim, n_classes),
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            return self.net(x)


class RewardGuidedFewShotRL:
    """
    Reward-guided fine-tuning layer used by the hybrid FT Few-Shot RL model.

    The class assumes embeddings are already produced by a language model. This
    makes it possible to test the decision layer independently from BERT. In the
    full experiment, BERT embeddings are updated through the same composite loss.
    """

    def __init__(self, n_classes: int, embedding_dim: int, config: RewardConfig | None = None) -> None:
        if torch is None:
            raise ImportError("PyTorch is required for RewardGuidedFewShotRL.")
        self.n_classes = n_classes
        self.embedding_dim = embedding_dim
        self.config = config or RewardConfig()
        self.policy = PolicyNetwork(embedding_dim, n_classes)

    def reward(self, predictions: torch.Tensor, true_labels: torch.Tensor, confidences: torch.Tensor | None = None) -> torch.Tensor:
        correct = predictions.eq(true_labels)
        rewards = torch.where(
            correct,
            torch.full_like(true_labels, self.config.correct_reward, dtype=torch.float32),
            torch.full_like(true_labels, self.config.incorrect_penalty, dtype=torch.float32),
        )
        if confidences is not None:
            low_conf = confidences < self.config.confidence_threshold
            rewards = rewards + torch.where(
                low_conf,
                torch.full_like(rewards, self.config.uncertain_penalty),
                torch.zeros_like(rewards),
            )
        return rewards

    def expert_targets(
        self,
        labels: torch.Tensor,
        corrections: Iterable[ExpertCorrection] | None,
        device: torch.device,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        target = labels.clone().to(device)
        weights = torch.zeros(len(labels), device=device)
        if corrections is None:
            return target, weights
        for item in corrections:
            if 0 <= item.index < len(labels):
                target[item.index] = int(item.corrected_label)
                weights[item.index] = float(np.clip(item.confidence, 0.0, 1.0))
        return target, weights

    def composite_loss(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        corrections: Iterable[ExpertCorrection] | None = None,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        device = embeddings.device
        logits = self.policy(embeddings)
        supervised_loss = F.cross_entropy(logits, labels)

        probs = F.softmax(logits, dim=1)
        dist = torch.distributions.Categorical(probs)
        actions = dist.sample()
        rewards = self.reward(actions, labels, probs.max(dim=1).values)
        policy_loss = -(dist.log_prob(actions) * rewards.detach()).mean()

        expert_labels, expert_weights = self.expert_targets(labels, corrections, device)
        if expert_weights.sum() > 0:
            per_item = F.cross_entropy(logits, expert_labels, reduction="none")
            expert_loss = (per_item * expert_weights).sum() / expert_weights.sum()
        else:
            expert_loss = torch.tensor(0.0, device=device)

        total = supervised_loss + self.config.lambda_rl * policy_loss + self.config.mu_expert * expert_loss
        stats = {
            "supervised_loss": float(supervised_loss.detach().cpu()),
            "policy_loss": float(policy_loss.detach().cpu()),
            "expert_loss": float(expert_loss.detach().cpu()),
            "mean_reward": float(rewards.mean().detach().cpu()),
        }
        return total, stats

    def fit_epoch(
        self,
        embeddings: np.ndarray,
        labels: Sequence[int],
        corrections: Iterable[ExpertCorrection] | None = None,
        learning_rate: float = 1e-3,
    ) -> dict[str, float]:
        device = next(self.policy.parameters()).device
        x = torch.tensor(embeddings, dtype=torch.float32, device=device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        optim = torch.optim.AdamW(self.policy.parameters(), lr=learning_rate)
        optim.zero_grad()
        loss, stats = self.composite_loss(x, y, corrections)
        loss.backward()
        optim.step()
        stats["total_loss"] = float(loss.detach().cpu())
        return stats

    def predict(self, embeddings: np.ndarray) -> np.ndarray:
        device = next(self.policy.parameters()).device
        x = torch.tensor(embeddings, dtype=torch.float32, device=device)
        self.policy.eval()
        with torch.no_grad():
            logits = self.policy(x)
            pred = logits.argmax(dim=1).cpu().numpy()
        self.policy.train()
        return pred


def build_episode(labels: Sequence[int], n_way: int = 2, n_shot: int = 5, seed: int = 42) -> tuple[np.ndarray, np.ndarray]:
    """Return support and query indices for one few-shot episode."""

    rng = np.random.default_rng(seed)
    labels = np.asarray(labels)
    classes = rng.choice(np.unique(labels), size=n_way, replace=False)
    support, query = [], []
    for cls in classes:
        idx = np.where(labels == cls)[0]
        rng.shuffle(idx)
        support.extend(idx[:n_shot])
        query.extend(idx[n_shot:])
    return np.asarray(support), np.asarray(query)
