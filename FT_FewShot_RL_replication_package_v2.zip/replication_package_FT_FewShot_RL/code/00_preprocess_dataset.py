"""
Preprocess PROMISE NFR dataset.

Expected input:
    data/PROMISE_NFR_dataset.csv

Expected columns:
    text,label

Output:
    data/processed_requirements.csv
"""

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
input_path = ROOT / "data" / "PROMISE_NFR_dataset.csv"
output_path = ROOT / "data" / "processed_requirements.csv"

if not input_path.exists():
    raise FileNotFoundError(
        f"Dataset not found: {input_path}\n"
        "Download the PROMISE NFR dataset and save it as data/PROMISE_NFR_dataset.csv"
    )

df = pd.read_csv(input_path)

# Adapt common column names if needed
possible_text_cols = ["text", "requirement", "Requirement", "sentence", "description"]
possible_label_cols = ["label", "class", "Class", "type", "category"]

text_col = next((c for c in possible_text_cols if c in df.columns), None)
label_col = next((c for c in possible_label_cols if c in df.columns), None)

if text_col is None or label_col is None:
    raise ValueError(
        f"Could not identify text/label columns. Found columns: {list(df.columns)}"
    )

df = df[[text_col, label_col]].rename(columns={text_col: "text", label_col: "label"})
df["text"] = df["text"].astype(str).str.strip()
df["label"] = df["label"].astype(str).str.strip()
df = df.dropna().drop_duplicates()

output_path.parent.mkdir(exist_ok=True, parents=True)
df.to_csv(output_path, index=False)
print(f"Saved processed dataset to {output_path}")
print(df["label"].value_counts())
