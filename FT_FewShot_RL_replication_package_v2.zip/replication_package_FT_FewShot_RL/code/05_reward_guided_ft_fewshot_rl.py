"""
Reward-guided FT Few-Shot RL style fine-tuning scaffold.

This script provides a transparent approximation of the manuscript workflow:
- few-shot support examples
- classifier update
- reward based on correct classification and confidence
- optional expert feedback weighting through corrected labels and confidence

It is intentionally lightweight so that readers can inspect and adapt it.
"""

from pathlib import Path
import time
import numpy as np
import pandas as pd
from sklearn.linear_model import SGDClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed_requirements.csv"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

LAMBDA_RL = 0.3
MU_EXPERT = 0.4
SHOTS = 5
EPOCHS = 5
RANDOM_STATE = 42

df = pd.read_csv(DATA)
train_df, test_df = train_test_split(
    df, test_size=0.2, random_state=RANDOM_STATE, stratify=df["label"]
)

support = train_df.groupby("label", group_keys=False).apply(
    lambda x: x.sample(min(len(x), SHOTS), random_state=RANDOM_STATE)
)

vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
X_support = vectorizer.fit_transform(support["text"])
y_support = support["label"].values
X_test = vectorizer.transform(test_df["text"])
y_test = test_df["label"].values
classes = np.unique(train_df["label"])

clf = SGDClassifier(loss="log_loss", random_state=RANDOM_STATE)

t0 = time.time()
for epoch in range(EPOCHS):
    # Base few-shot update
    clf.partial_fit(X_support, y_support, classes=classes)

    # Reward-guided pseudo-update: emphasize confident/correct examples.
    prob = clf.predict_proba(X_support)
    pred = clf.classes_[np.argmax(prob, axis=1)]
    conf = np.max(prob, axis=1)

    reward = np.where(pred == y_support, 1.0, -1.0) * conf
    sample_weight = 1.0 + LAMBDA_RL * np.maximum(reward, 0)

    # Expert feedback approximation:
    # in a real HITL setting, replace y_support with corrected expert labels
    # and use expert confidence as expert_weight.
    expert_confidence = np.ones_like(sample_weight) * 0.8
    sample_weight = sample_weight + MU_EXPERT * expert_confidence

    clf.partial_fit(X_support, y_support, classes=classes, sample_weight=sample_weight)

train_time = time.time() - t0

t1 = time.time()
pred_test = clf.predict(X_test)
infer_ms = (time.time() - t1) * 1000 / len(test_df)

p, r, f1, _ = precision_recall_fscore_support(y_test, pred_test, average="weighted", zero_division=0)
acc = accuracy_score(y_test, pred_test)

out = pd.DataFrame([{
    "model": "FT Few-Shot RL / Reward-Guided Fine-Tuning",
    "lambda_rl": LAMBDA_RL,
    "mu_expert": MU_EXPERT,
    "shots": SHOTS,
    "epochs": EPOCHS,
    "precision_weighted": p,
    "recall_weighted": r,
    "f1_weighted": f1,
    "accuracy": acc,
    "training_time_seconds": train_time,
    "inference_time_ms_per_sample": infer_ms
}])

out.to_csv(RESULTS / "ft_fewshot_rl_metrics.csv", index=False)
print(out.to_string(index=False))
