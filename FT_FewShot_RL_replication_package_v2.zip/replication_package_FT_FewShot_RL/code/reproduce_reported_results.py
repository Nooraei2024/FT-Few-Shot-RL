"""
Reproduce the manuscript tables and figures from the extracted result workbook.

This script does not retrain the models. It reads the numerical values reported in
results/extracted_results_from_manuscript.xlsx and regenerates CSV tables and plots.
That is intentional: it provides a stable check that the reported manuscript values,
figures, and tables are internally consistent.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_XLSX = ROOT / "results" / "extracted_results_from_manuscript.xlsx"
TABLE_DIR = ROOT / "outputs" / "tables"
FIG_DIR = ROOT / "outputs" / "figures"


def _mkdirs() -> None:
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    FIG_DIR.mkdir(parents=True, exist_ok=True)


def read_sheet(workbook: Path, sheet_name: str) -> pd.DataFrame:
    df = pd.read_excel(workbook, sheet_name=sheet_name)
    # Excel exports sometimes contain trailing empty columns.
    df = df.dropna(axis=1, how="all")
    df = df.dropna(how="all")
    return df


def save_clean_tables(workbook: Path) -> dict[str, pd.DataFrame]:
    tables = {
        "performance": read_sheet(workbook, "Table3_Performance"),
        "data_ablation": read_sheet(workbook, "Table4_Data_Ablation"),
        "component_ablation": read_sheet(workbook, "Component_Ablation"),
        "hyperparameters": read_sheet(workbook, "Hyperparameters"),
        "expert_metrics": read_sheet(workbook, "Expert_Metrics"),
    }

    tables["performance"].to_csv(TABLE_DIR / "table3_performance.csv", index=False)
    tables["data_ablation"].to_csv(TABLE_DIR / "table4_data_ablation.csv", index=False)
    tables["component_ablation"].to_csv(TABLE_DIR / "component_ablation.csv", index=False)
    tables["hyperparameters"].to_csv(TABLE_DIR / "appendix_hyperparameters.csv", index=False)
    tables["expert_metrics"].to_csv(TABLE_DIR / "appendix_expert_metrics.csv", index=False)
    return tables


def plot_performance(df: pd.DataFrame) -> None:
    metrics = ["F1-Score", "Precision", "Recall", "Accuracy"]
    tasks = list(df["Task"].dropna().unique())

    for task in tasks:
        part = df[df["Task"] == task].copy()
        x = np.arange(len(part))
        width = 0.18

        fig, ax = plt.subplots(figsize=(12, 6))
        for i, metric in enumerate(metrics):
            ax.bar(x + (i - 1.5) * width, part[metric].astype(float), width, label=metric)

        ax.set_title(f"Performance comparison - {task}")
        ax.set_ylabel("Score")
        ax.set_ylim(0, 1.05)
        ax.set_xticks(x)
        ax.set_xticklabels(part["Model"], rotation=25, ha="right")
        ax.legend(loc="lower right")
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()

        safe = task.lower().replace("/", "_").replace(" ", "_")
        fig.savefig(FIG_DIR / f"fig2_{safe}.png", dpi=300)
        plt.close(fig)

    # A compact manuscript-style view focused on F1.
    pivot = df.pivot(index="Model", columns="Task", values="F1-Score")
    ax = pivot.plot(kind="bar", figsize=(11, 6))
    ax.set_title("F1-score comparison across requirement classification tasks")
    ax.set_ylabel("F1-score")
    ax.set_ylim(0, 1.05)
    ax.grid(axis="y", alpha=0.25)
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "fig2_performance_comparison.png", dpi=300)
    plt.close()


def plot_data_ablation(df: pd.DataFrame) -> None:
    data_cols = ["10% Data (F1)", "20% Data (F1)", "30% Data (F1)", "40% Data (F1)", "Full Data (F1)"]
    x = [10, 20, 30, 40, 100]

    for task in df["Task"].dropna().unique():
        part = df[df["Task"] == task]
        fig, ax = plt.subplots(figsize=(9, 6))
        for _, row in part.iterrows():
            y = [float(row[c]) for c in data_cols]
            ax.plot(x, y, marker="o", label=row["Model"])
        ax.set_title(f"Data ablation - {task}")
        ax.set_xlabel("Training data used (%)")
        ax.set_ylabel("F1-score")
        ax.set_ylim(0.5, 1.0)
        ax.grid(alpha=0.25)
        ax.legend()
        fig.tight_layout()
        safe = task.lower().replace("/", "_").replace(" ", "_")
        fig.savefig(FIG_DIR / f"fig3_{safe}.png", dpi=300)
        plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 6))
    key = df[df["Model"].isin(["Supervised (SVM)", "Transfer Learning (BERT)", "FT Few-Shot RL"])]
    for (task, model), part in key.groupby(["Task", "Model"]):
        row = part.iloc[0]
        y = [float(row[c]) for c in data_cols]
        ax.plot(x, y, marker="o", label=f"{task}: {model}")
    ax.set_title("F1-score under reduced training data")
    ax.set_xlabel("Training data used (%)")
    ax.set_ylabel("F1-score")
    ax.set_ylim(0.55, 1.0)
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig3_data_ablation.png", dpi=300)
    plt.close(fig)


def heatmap(matrix: pd.DataFrame, title: str, filename: str) -> None:
    values = matrix.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(9, 5.8))
    im = ax.imshow(values, aspect="auto", vmin=0.75, vmax=0.95)
    ax.set_xticks(np.arange(matrix.shape[1]))
    ax.set_xticklabels(matrix.columns, rotation=25, ha="right")
    ax.set_yticks(np.arange(matrix.shape[0]))
    ax.set_yticklabels(matrix.index)
    ax.set_title(title)

    for i in range(values.shape[0]):
        for j in range(values.shape[1]):
            ax.text(j, i, f"{values[i, j]:.2f}", ha="center", va="center")

    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(FIG_DIR / filename, dpi=300)
    plt.close(fig)


def plot_component_ablation(df: pd.DataFrame) -> None:
    f1 = df.pivot(index="Variant", columns="Task", values="F1-Score")
    acc = df.pivot(index="Variant", columns="Task", values="Accuracy")
    heatmap(f1, "Component ablation - F1-score", "fig4_component_ablation_f1.png")
    heatmap(acc, "Component ablation - Accuracy", "fig4_component_ablation_accuracy.png")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workbook", default=DEFAULT_XLSX, type=Path)
    args = parser.parse_args()

    _mkdirs()
    tables = save_clean_tables(args.workbook)
    plot_performance(tables["performance"])
    plot_data_ablation(tables["data_ablation"])
    plot_component_ablation(tables["component_ablation"])

    print("Reported-result reproduction completed.")
    print(f"Tables:  {TABLE_DIR}")
    print(f"Figures: {FIG_DIR}")


if __name__ == "__main__":
    main()
